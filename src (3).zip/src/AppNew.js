
import { BrowserRouter } from "react-router-dom";
import GuestSmallNav from "./components/Guest/GuestSmallNav";
import { Homepages } from "./components/Homepages";
import { Login } from "./components/Login";

import Registration from "./components/Registration";



function AppNew() {
    return (
        <div>
     <Login/>
        </div>

    );}
export default AppNew;