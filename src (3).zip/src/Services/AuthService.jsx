import axios from "axios";
const BASE_URL="http://localhost:8080";
class AuthService{
    
    registerUser(userObject){
        return axios({
            method:'post',
            url:BASE_URL+'/auth/signup',
            data:userObject,
            headers:{'X-Custom-Header': 'foobar'}
        });
    }

    loginUser(userObject){
        console.log("authservice")
        return axios({
            method:'post',
            url:BASE_URL+'/auth/token',
            data:userObject,
            headers:{'X-Custom-Header': 'foobar'}
        });
        
    }

}
export default new AuthService();
