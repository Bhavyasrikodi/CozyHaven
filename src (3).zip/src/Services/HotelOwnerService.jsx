import axios from "axios";

class HotelOwnerService{
    BASE_URL="http://localhost:8080/api/v1/havenstay"
    getReservationsOfHotel(hotelId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/owner/getReservationsOfParticularHotel?hotelId="+hotelId,
             responseType: 'json',
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
       }
       getGuestsOfHotel(hotelId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/owner/getGuestsOfParticularHotel?hotelId="+hotelId,
             responseType: 'json',
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
       }
       getRoomsOfHotel(hotelId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/owner/getRoomsOfParticularHotel?hotelId="+hotelId,
             responseType: 'json',
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
       }
       updateRoom(roomObj,roomId,token){
        return axios({
             method: 'put',
             url: this.BASE_URL+"/room/editroom?roomId="+roomId,
             data: roomObj,
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
       }
       findById(roomId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/room/getroomid?roomId="+roomId,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
              'Authorization': `Bearer ${token}`
             }
           })
       }
       findByHotelId(hotelId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/hotel/gethotelByid?hotelId="+hotelId,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
              'Authorization': `Bearer ${token}`
             }
           })
          
       }
      saveRoom(roomObj,hotelId,token){
        console.log("hotelId service"+hotelId)
        return axios({
             method: 'post',
             url: this.BASE_URL+"/room/createRoom?hotelId="+hotelId,
             data: roomObj,
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
          
       }

      deleteRoom(roomId,token){
        return axios({
          method: 'delete',
          url: this.BASE_URL+"/room/deleteroom?roomId="+roomId,
          responseType: 'json',
          headers: {'Access-Control-Allow-Origin': '*',
            'Authorization': `Bearer ${token}`
          }
        })
      }
      
      findHotelIdByUsername(username,token){
        console.log("service findHotelId by user name")
        return axios({
             method: 'get',
             url: this.BASE_URL+"/owner/getHotelId?username="+username,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
              'Authorization': `Bearer ${token}`
             }
           })
          
       }

       saveHotel(hotelObj,token){
        console.log("save hotel from service")
        return axios({
             method: 'post',
             url: this.BASE_URL+"/hotel/createhotel",
             data: hotelObj,
             headers: {'X-Custom-Header': 'foobar',
              'Authorization': `Bearer ${token}`
             }
           })
          
       }
       getRefundList(hotelId,token){
        console.log("refund list")
        return axios({
             method: 'get',
             url: this.BASE_URL+"/owner/pendingrequests?hotelId="+hotelId,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
              'Authorization': `Bearer ${token}`
             }
           })
           
       }
       getGuestName(guestId,token){
        return axios({
             method: 'get',
             url: this.BASE_URL+"/guest/getguestid?guestId="+guestId,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
              'Authorization': `Bearer ${token}`
             }
           })
          
       }

       getOwnerid(username,token){
        return axios({
          method: 'get',
          url: this.BASE_URL+"/owner/getOwneridbyUsername?username="+username,
          responseType: 'json',
          headers: {'Access-Control-Allow-Origin': '*',
            'Authorization': `Bearer ${token}`
          }
        })
       }

       getReviews(hotelId,token){
        return axios({
          method: 'get',
          url: this.BASE_URL+"/owner/getAllReviewsOfHotel?hotelId="+hotelId,
          responseType: 'json',
          headers: {'Access-Control-Allow-Origin': '*',
            'Authorization': `Bearer ${token}`
          }
        })
       }

       sendRefund(paymentId,token){
        return axios({
          method: 'put',
          url: this.BASE_URL+"/reservation/refundBypaymentId?paymentId="+paymentId,
          headers: {'X-Custom-Header': 'foobar',
           'Authorization': `Bearer ${token}`
          }
        })
       }
}

export default new HotelOwnerService();