import axios from "axios"

class AdminService{
    BASE_URL="http://localhost:8080/api/v1/havenstay"
    getAllHotels(token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/hotel/getallhotels",
            responseType: 'stream',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        })
    }
    

    // findByOwnerId(ownerid,token){
    //     return axios({
    //          method: 'get',
    //          url: this.BASE_URL+"/owner/getHotelOwnerbyid?ownerId="+ownerid,
    //          responseType: 'json',
    //          headers: {'Access-Control-Allow-Origin': '*',
    //             'Authorization': `Bearer ${token}`
    //          }
    //        })
    //    }

    // findByHotelId(hotelId){
    //     return axios({
    //         method:'get',
    //         url:this.BASE_URL+"/hotel/gethotelByid?hotelId="+hotelId,
    //         responseType:"json",
    //         headers: {'Access-Control-Allow-Origin': '*'}
    //     })
    // }


    getAllOwners(token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/owner/getAllOwners",
            responseType: 'stream',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        })

    }

    getAllReservations(token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/reservation/getallreservations",
            responseType: 'stream',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        })

    }

    getAllGuests(token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/guest/getAllGuests",
            responseType: 'stream',
            headers: {'X-Custom-Header': 'foobar'},
            'Authorization': `Bearer ${token}`
        })
    }

    findByGuestId(guestId,token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/guest/getguestid?guestId="+guestId,
            responseType:'json',
            headers:{'Access-Control-Allow-Origin': '*',
                'Authorization': `Bearer ${token}`
            }
        })
    }


    // updateHotelbyOwnerId(hotelObj,hotelId,ownerId){
    //     return axios({
    //         method:'put',
    //         url:this.BASE_URL+"/hotel/updatehotel?hotelId="+hotelId+"&ownerId="+ownerId,
    //         data:hotelObj,
    //         headers:{'X-Custom-Header': 'foobar'}
    //     })
    // }

    deleteGuest(guestId,token){
        return axios({
             method: 'delete',
             url: this.BASE_URL+"/admin/guests?guestId="+guestId,
             responseType: 'json',
             headers: {'Access-Control-Allow-Origin': '*',
                'Authorization': `Bearer ${token}`
             }
           })
       }

    deleteOwner(ownerId,token){
        return axios({
            method:'delete',
            url:this.BASE_URL+"/admin/hotelOwner?hotelOwnerId="+ownerId,
            responseType:'json',
            headers:{'Access-Control-Allow-Origin': '*',
                'Authorization': `Bearer ${token}`
            }
        })
    }

   
}
export default new AdminService();