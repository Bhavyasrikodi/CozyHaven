import axios from "axios";

class GuestService{
    BASE_URL="http://localhost:8080/api/v1/havenstay"
    
    // findHotelByLocation(location){
    //     console.log("servicesearch");
    //     return axios({
    //         method:'get',
    //         url:this.BASE_URL+"/hotel/gethotelsbylocation?location="+location,
    //         responseType:'json',
    //         headers: {'X-Custom-Header': 'foobar'}
    //     })
    // }
    getAllHotels(token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/hotel/getallhotels",
            responseType: 'stream',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        })
    }

    // findHotelByduration(startDate,endDate,token){
    //     return axios({
    //         method:'get',
    //         url:this.BASE_URL+`/hotel/gethotelbyduration/${startDate},${endDate}`,
    //         responseType:'json',
    //         headers: {'X-Custom-Header': 'foobar',
    //             'Authorization': `Bearer ${token}`
    //         }
    //     })
    // }

    getRoomsByHotel(hotelId,token){
        return axios({
            method:'get',
            url:this.BASE_URL+"/room/getroomsbyhotel?hotelId="+hotelId,
            responseType:'json',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        })
    }

    // getRoomsByHotelAndDate(hotelId, startDate, endDate){
    //     return axios({
    //         method:'get',
    //         url:this.BASE_URL+"/room/getroomsbyhotel?hotelId="+hotelId,
    //         responseType:'json',
    //         headers: {'X-Custom-Header': 'foobar'}
    //     })
    // }

    searchHotels(location, startDate, endDate,token) {
        return axios({
            method: 'get',
            url: this.BASE_URL+"/hotel/gethotelbyduration?location="+location+"&startDate="+startDate+"&endDate="+endDate,
            responseType: 'json',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        });
    }
    
    getAvailableRoomsByHotelLocation(location, startDate, endDate,token) {
        return axios({
            method: 'get',
            url: `${this.BASE_URL}/room/availablerooms?location=${location}&startDate=${startDate}&endDate=${endDate}`,
            responseType: 'json',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        });
    }

    reserveRoom(guestId, roomId, reservationObj,token) {
        return axios({
          method: 'post',
          url: this.BASE_URL+`/reservation/reservesRooms`, // Base URL without query params
          params: { guestId, roomId },  // Use `params` to pass query parameters
          data: reservationObj,  // Send the reservation object in the request body
          headers: { 'X-Custom-Header': 'foobar',
            'Authorization': `Bearer ${token}`
           }  // If needed, otherwise can be removed
        })
        
      }

      getGuestIdByUsername(username,token) {
        return axios({
            method: 'get',
            url:this.BASE_URL+ "/guest/getguestidbyusername?username="+username,
            responseType: 'json',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        });
    }

    getBookingHistory(guestId,token){
        return axios({
            method: 'get',
            url:this.BASE_URL+`/reservation/getreservationbyguestId`,
            params:{guestId},
            responseType: 'json',
            headers: {'X-Custom-Header': 'foobar',
                'Authorization': `Bearer ${token}`
            }
        });
        
    }

    paymentDone(guestId,reservationId,paymentObj,token){
        return axios({
            method: 'post',
            url: this.BASE_URL+`/payment/paynow`, // Base URL without query params
            params: {guestId,reservationId },  // Use `params` to pass query parameters
            data: paymentObj,  // Send the reservation object in the request body
            headers: { 'X-Custom-Header': 'foobar' ,
                'Authorization': `Bearer ${token}`
            }  // If needed, otherwise can be removed
          })
    }
    
   rateNow(guestId,hotelId,reviewObj,token){
    return axios({
        method: 'post',
        url: this.BASE_URL+`/review/giveReview`, // Base URL without query params
        params: {guestId,hotelId },  // Use `params` to pass query parameters
        data: reviewObj,  // Send the reservation object in the request body
        headers: { 'X-Custom-Header': 'foobar',
            'Authorization': `Bearer ${token}`
         }  // If needed, otherwise can be removed
      })
   }

   requestRefund(reservationId,token){
    return axios({
        method:'put',
        url:this.BASE_URL+"/reservation/cancelByreservationId?reservationId="+reservationId,
        responseType: 'json',
        headers: {'X-Custom-Header': 'foobar',
            'Authorization': `Bearer ${token}`
        }
    })
   }

   downloadBill(paymentId,token){
    return axios({
        method: 'get',
        url:this.BASE_URL+`/payment/downloadbill`,
        params:{paymentId},
        responseType: 'blob',
        headers: {'X-Custom-Header': 'foobar',
            'Authorization': `Bearer ${token}`
        }
    });
    
   }

  
   

}
export default new GuestService();