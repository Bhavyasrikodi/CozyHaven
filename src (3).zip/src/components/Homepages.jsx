import React from 'react';
import Homenavigation from './Homenavigation';
import { Carousel } from 'react-bootstrap'; // Import Carousel component
import caruosel1 from './images/caruosel1.jpg'; // Import images from your images folder
import caruosel2 from './images/caruosel2.jpg';
import caruosel3 from './images/caruosel3.jpg';
import './Homepage.css';
export const Homepages = () => {
  return (
    <div>
      <Homenavigation />
      <Carousel>
        <Carousel.Item>
          <img
            className="carousel-image"
            src={caruosel1}
            alt="Taj"
          />
          <Carousel.Caption>
            <h3>Taj</h3>
            <p>Experience luxury and comfort at Taj.</p>
          </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item>
          <img
            className="carousel-image"
            src={caruosel2}
            alt="Grand Hyatt"
          />
          <Carousel.Caption>
            <h3>Grand Hyatt</h3>
            <p>Relax and unwind in the serene atmosphere of Grand Hyatt.</p>
          </Carousel.Caption>
        </Carousel.Item>

        <Carousel.Item>
          <img
            className="carousel-image"
            src={caruosel3}
            alt="Pink Palace"
          />
          <Carousel.Caption>
            <h3>Pink Palace</h3>
            <p>Explore the city from the comfort of Pink Palace.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>
    </div>
  );
}
