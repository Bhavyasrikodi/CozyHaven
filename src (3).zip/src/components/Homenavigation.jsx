import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Image } from 'react-bootstrap';
import "./Homepage.css";

import logoImage from './images/cozyhavenlogo.jpg';


export const Homenavigation = () => {
  return (
    <Navbar expand="lg" className="custom-navbar">
          <Container fluid>
          <Navbar.Brand >
              <Image   src={logoImage}
               alt="CozyHavenLogo" height="50" width="50"/>
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="navbarScroll" 
            onError={(e) => {
              console.error("Error loading image:", e);
              e.target.src = 'https://via.placeholder.com/150?text=CozyHaven'; // Fallback image
            }}
            />
            <h3>Welcome to Cozy Haven Hotels</h3>
            <Navbar.Collapse id="navbarScroll">
              <Nav
                className="me-auto my-2 my-lg-0"
                style={{ maxHeight: '100px' }}
                navbarScroll
              >
                
               
              </Nav>
              
              <button className="homebutton"><Nav.Link href="/register">Signup</Nav.Link></button>&nbsp;&nbsp;&nbsp;
              <button className="homebutton"><Nav.Link  href="/login">Login</Nav.Link></button>
              
            </Navbar.Collapse>
          </Container>
        </Navbar>
      );
}
export default Homenavigation;