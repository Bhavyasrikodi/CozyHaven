import { useEffect, useState } from "react";
import AdminService from "../../Services/AdminService";
import AdminNavigation from "./AdminNavigation";
import './ReservationList.css';  // Import the custom CSS file
import { useAuth } from "../../context/useAuth";

export const ReservationList = () => {
    const [reservations, setReservations] = useState([]);
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(() => {
        AdminService.getAllReservations(token).then((response) => {
            setReservations(JSON.parse(response.data));
        }).catch((error) => {
            console.log(error);
        });
    }, []);

    return (
        <div>
            <AdminNavigation />
            <h2 className="text-center">Reservation Listings</h2>
            <div className="table-responsive custom-table-container"> {/* Adjust the table container */}
                <table className="table table-striped table-bordered table-hover custom-table">
                    <thead className="table-header">
                        <tr>
                            <th>Guest Name</th>
                            <th>Phone Number</th>
                            <th>Hotel Name</th>
                            <th>Location</th>
                            <th>Room Number</th>
                            <th>Bed Preferences</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Number of Persons</th>
                            <th>Reservation Status</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        {reservations.map((reservation, key) =>
                            <tr key={reservation.reservationId} className="table-row">
                                <td>{reservation.guestName}</td>
                                <td>{reservation.phoneNumber}</td>
                                <td>{reservation.hotelName}</td>
                                <td>{reservation.location}</td>
                                <td>{reservation.roomNumber}</td>
                                <td>{reservation.bedPreferences}</td>
                                <td>{reservation.startDate}</td>
                                <td>{reservation.endDate}</td>
                                <td>{reservation.numberOfPersons}</td>
                                <td>{reservation.reservationStatus}</td>
                                <td>{reservation.totalPrice}</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
