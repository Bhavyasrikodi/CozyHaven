import { useEffect, useState } from "react";
import AdminService from "../../Services/AdminService";
import { useParams } from "react-router-dom";
import AdminNavigation from "./AdminNavigation";
import './GuestList.css';  // Import the custom CSS file
import { useAuth } from "../../context/useAuth";

export const GuestList = () => {
    const [guests, setGuests] = useState([]);
    const [deleteGuest, setDeleteGuest] = useState([false]);
    const { guestId } = useParams();
    const {auth}=useAuth();
    const token=auth.token;
    const deleteGuests = (guestId) => {
        AdminService.deleteGuest(guestId,token).then((response) => {
            setDeleteGuest(!deleteGuest);
        });
    }

    useEffect(() => {
        AdminService.getAllGuests(token).then((response) => {
            setGuests(JSON.parse(response.data));
        }).catch((error) => {
            console.log(error);
        })
    }, [deleteGuest]);

    return (
        <div>
            <AdminNavigation />
            <h2 className="text-center">Guest Listings</h2>
            <div className="table-responsive custom-table-container"> {/* Adjust the table container */}
                <table className="table table-striped table-bordered table-hover custom-table">
                    <thead className="table-header">
                        <tr>
                            <th>Guest Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Gender</th>
                            <th>Aadhar Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {guests.map((guest, key) =>
                            <tr key={guest.guestId} className="table-row">
                                <td>{guest.guestName}</td>
                                <td>{guest.email}</td>
                                <td>{guest.phoneNumber}</td>
                                <td>{guest.gender}</td>
                                <td>{guest.aadharNumber}</td>
                                <td>
                                    <button onClick={() => deleteGuests(guest.guestId)} className="btn btn-danger">Delete</button>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
