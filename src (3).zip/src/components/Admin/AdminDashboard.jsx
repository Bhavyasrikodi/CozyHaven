import React, { useEffect, useState } from 'react';
import AdminService from '../../Services/AdminService';
import AdminNavigation from './AdminNavigation';
import './AdminPage.css'; // Import the custom CSS
import { useAuth } from '../../context/useAuth';

export const AdminDashboard = () => {
  const [hotels, setHotels] = useState([]);
  const {auth}=useAuth();
  const token=auth.token;
  useEffect(() => {
    console.log('useEffect fired');
    AdminService.getAllHotels(token)
      .then((response) => {
        console.log('data received from HOTELS' + JSON.stringify(response.data));
        setHotels(JSON.parse(response.data));
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <div className="admin-dashboard">
      <AdminNavigation />
      {console.log('application rendered...')}
      <h2 className="text-center">Hotel Listings</h2>
      <div className="table-responsive custom-table-container"> {/* Table container */}
        <table className="table table-bordered table-striped table-hover custom-table"> {/* Custom table */}
          <thead className="table-header">
            <tr>
              <th>Hotel Name</th>
              <th>Location</th>
              <th>Hotel Owner Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Business License</th>
              
            </tr>
          </thead>
          <tbody>
            {hotels.map((hotel, key) => (
              <tr key={hotel.hotelId} className="table-row">
                <td>{hotel.hotelName}</td>
                <td>{hotel.location}</td>
                <td>{hotel.hotelOwnerName}</td>
                <td>{hotel.email}</td>
                <td>{hotel.phoneNumber}</td>
                <td>{hotel.businessLicense}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
