import { useEffect, useState } from "react";
import AdminService from "../../Services/AdminService";
import { useParams } from "react-router-dom";
import AdminNavigation from "./AdminNavigation";
import './OwnerList.css';  // Import the custom CSS file
import { useAuth } from "../../context/useAuth";

export const OwnerList = () => {
    const [owners, setOwners] = useState([]);
    const [deleteOwner, setDeleteOwner] = useState(false);
    const { ownerId } = useParams();
    const {auth}=useAuth();
    const token=auth.token;
    const deleteOwners = (ownerId) => {
        AdminService.deleteOwner(ownerId,token).then((response) => {
            setDeleteOwner(!deleteOwner);
        });
    };

    useEffect(() => {
        AdminService.getAllOwners(token).then((response) => {
            setOwners(JSON.parse(response.data));
        }).catch((error) => {
            console.log(error);
        });
    }, [deleteOwner]);

    return (
        <div>
            <AdminNavigation />
            <h2 className="text-center">Owner Listings</h2>
            <div className="table-responsive custom-table-container">
                <table className="table table-striped table-bordered table-hover custom-table">
                    <thead className="table-header">
                        <tr>
                            <th>Hotel Owner Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Business License</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {owners.map((owner, key) =>
                            <tr key={owner.ownerId} className="table-row">
                                <td>{owner.hotelOwnerName}</td>
                                <td>{owner.email}</td>
                                <td>{owner.phoneNumber}</td>
                                <td>{owner.businessLicense}</td>
                                <td>
                                    <button onClick={() => { deleteOwners(owner.ownerId) }} className='btn btn-danger'>Delete</button>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
