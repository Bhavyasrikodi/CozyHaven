
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Image } from 'react-bootstrap';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { FaUserCircle } from 'react-icons/fa';
import logoImage from '../images/cozyhavenlogo.jpg';
import { Link } from 'react-router-dom';
import Logout from '../Logout';

function AdminNavigation() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container fluid>
      <Navbar.Brand as={Link} to="/admin-displayhotels">
          <Image   src={logoImage}
           alt="CozyHavenLogo" height="50" width="50"/>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" 
        onError={(e) => {
          console.error("Error loading image:", e);
          e.target.src = 'https://via.placeholder.com/150?text=CozyHaven'; // Fallback image
        }}
        />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link as={Link} to="/admin-guests">Guests</Nav.Link>
            <Nav.Link as={Link} to="/admin-reservations">Reservations</Nav.Link>
            <Nav.Link as={Link} to="/admin-owners">Owners</Nav.Link>
            
          </Nav>
          
          <NavDropdown 
              title={<FaUserCircle size={40} />} 
              id="navbarScrollingDropdown"
              align="end"
            >
               <NavDropdown.Item  id="navbarScrollingDropdown"><Logout/></NavDropdown.Item>
            </NavDropdown>
       
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default AdminNavigation;
