
import React, { useContext } from 'react'
import { AuthContext } from '../context/AuthProvider'
import { useLocation,Outlet, Navigate } from 'react-router-dom'

const RequireAuth = () => {
    
    const {auth}=useContext(AuthContext)
    const location=useLocation()

  return (
 
       
    auth?.role?<Outlet/>:<Navigate to="/login" state={{from:location}}replace/>
 
)
}
export default RequireAuth;
