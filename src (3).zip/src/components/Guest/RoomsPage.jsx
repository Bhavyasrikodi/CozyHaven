import React, { useState, useEffect } from 'react';
import GuestService from '../../Services/GuestService'; // Assuming this service will fetch room details
import './Rooms.css'; // Style for your room grid and buttons
import { useNavigate, useParams } from 'react-router-dom';
import GuestSmallNav from './GuestSmallNav';
import { useAuth } from '../../context/useAuth';

const RoomsPage = () => {
  const {username, hotelId } = useParams(); // Extract the hotel ID from the route
  const [rooms, setRooms] = useState([]);
  const {auth}=useAuth();
  const token=auth.token;
  useEffect(() => {
   
    GuestService.getRoomsByHotel(hotelId,token)
      .then((response) => {
        setRooms(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [hotelId,username]);

  return (
    <div className="rooming">
      <GuestSmallNav/>
      <div className="rooms-grid">
      {rooms.length > 0 ? (
        rooms.map((room) => (
          <RoomCard key={room.roomNumber} room={room} />
        ))
      ) : (
        <p>No rooms available for this hotel.</p>
      )}
    </div>
    </div>
  );
};


const RoomCard = ({ room }) => {
  const [showDetails, setShowDetails] = useState(false);
  const navigate = useNavigate(); 
  const {username,hotelId}=useParams();
  const toggleDetails = () => setShowDetails(!showDetails);

  const handleBookNow = () => {
    navigate(`/bookingPage/${username}/${hotelId}/${room.roomId}`);
  };

  return (
    <div className="room-card" onClick={toggleDetails}>
      <img src={room.roomimageurl} alt={room.roomNumber} className="room-image" />
      <h3>Room {room.roomNumber}</h3>
      <p>{room.bedPreferences}</p>

      {/* Expand to show detailed features */}
      {showDetails && (
        <div className="room-details">
          <p>Base Fare: Rs.{room.baseFare}</p>
          <p>Max Occupancy: {room.maxOccupancy} people</p>
          <p>AC: {room.isAc ? 'Yes' : 'No'}</p>
        </div>
      )}

      {/* "Book Now" button */}
      <button onClick={handleBookNow}>Book Now</button>
    </div>
  );
};

export default RoomsPage;
