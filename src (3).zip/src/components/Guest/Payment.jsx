import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import GuestService from '../../Services/GuestService';
import GuestSmallNav from './GuestSmallNav';
import { useAuth } from '../../context/useAuth';
import './Payment.css';
import axios from 'axios'; // Ensure axios is imported

export const Payment = () => {
    const [amount, setAmount] = useState(0);
    const [paymentDate, setPaymentDate] = useState(''); 
    const [message, setMessage] = useState(''); 
    const [error, setError] = useState(''); 
    const { reservationId, username } = useParams();
    const location = useLocation();
    const totalPrice = location.state?.totalPrice || 0;
    const { auth } = useAuth();
    const token = auth.token;
    const [paymentId, setPaymentId] = useState(null); // State to store paymentId after successful payment

    useEffect(() => {
        const today = new Date().toISOString().split("T")[0];
        setPaymentDate(today);
    }, []);

    const payNow = (e) => {
        e.preventDefault();
        const paymentObj = { amount, paymentDate };

        GuestService.getGuestIdByUsername(username, token)
            .then((response) => {
                GuestService.paymentDone(response.data, reservationId, paymentObj, token)
                    .then((response) => {
                        console.log("Payment successful: ", response.data);
                        setPaymentId(response.data.paymentId); // Store paymentId from response
                        setMessage('Payment successful!');
                        setAmount(0);
                        setPaymentDate('');
                    })
                    .catch((error) => {
                        console.error("Error processing payment: ", error);
                        setError('Payment failed. Please try again.');
                    });
            })
            .catch((error) => {
                console.error("Error fetching guest ID: ", error);
                setError('Error fetching guest ID. Please try again.');
            });
    };

    // Function to handle bill download
    const downloadPaymentBill = () => {
        if (!paymentId) {
            setError('No payment ID available for bill download.');
            return;
        }
    
        GuestService.downloadBill(paymentId, token)
            .then((response) => {
                // Check if the response has data and correct type
                if (response.data) {
                    const blob = new Blob([response.data], { type: 'application/pdf' });
                    const link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = `PaymentBill_${paymentId}.pdf`;
                    link.click();
                } else {
                    setError('No data received for the bill.');
                }
            })
            .catch((error) => {
                console.error("Error downloading the bill: ", error);
                setError('Failed to download the bill.');
            });
    };
    
    return (
        <div>
            <GuestSmallNav />
            <div id="payback">
                <div className="d-flex justify-content-center align-items-center vh-100">
                    <div className="payment-container card p-4" style={{ width: '400px' }}>
                        <h1 className="text-center">Happy Payment</h1>
                        <h3 className="text-center">Pay Rs.{totalPrice}</h3> 

                        <form onSubmit={payNow} className="paymentform">
                            <div className="form-group mb-3">
                                <label htmlFor="amount">Amount</label>
                                <input
                                    type="number"
                                    id="amount"
                                    name="amount"
                                    value={amount}
                                    onChange={(e) => setAmount(e.target.value)}
                                    required
                                    className="form-control"
                                />
                            </div>

                            <div className="form-group mb-3">
                                <label htmlFor="paymentDate">Payment Date</label>
                                <input
                                    type="date"
                                    id="paymentDate"
                                    min={new Date().toISOString().split("T")[0]} 
                                    name="paymentDate"
                                    value={paymentDate}
                                    readOnly
                                    required
                                    className="form-control"
                                />
                            </div>

                            <button type="submit" className="btn btn-primary w-100">
                                Do Pay
                            </button>
                        </form>
                        
                        {message && (
                            <>
                                <div className="alert alert-success mt-3">{message}</div>
                                <button 
                                    className="btn btn-secondary w-100 mt-3" 
                                    onClick={downloadPaymentBill}
                                >
                                    Download Payment Bill
                                </button>
                            </>
                        )}

                        {error && <div className="alert alert-danger mt-3">{error}</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Payment;
