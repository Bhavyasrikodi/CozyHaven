import React from 'react';
import { useLocation, Link, useParams } from 'react-router-dom';
import {  Row, Col, Card, Button } from 'react-bootstrap';
import GuestSmallNav from './GuestSmallNav';
import { useAuth } from '../../context/useAuth';

const Hotelsearch = () => {
    const location = useLocation();
    const { hotels } = location.state || { hotels: [] }; // Get hotels from location state
    const{username}=useParams();
    
    return (
        <div>
            <GuestSmallNav/>
            <div className="hotel-grid">
        {hotels.length > 0 ? (
          hotels.map((hotel) => (
            <div key={hotel.hotelName} className="hotel-card">
              <img src={hotel.imageurl} alt={hotel.hotelName} className="hotel-image" />
              <h2>{hotel.hotelName}</h2>
              <p>{hotel.location}</p>
              <div className="hotel-rating">
                {[...Array(Math.floor(hotel.rating))].map((_, i) => (
                  <span key={i}>&#9733;</span> // Unicode for filled star
                ))}
              </div>
              <ul className="amenities">
                <li>Dining: {hotel.isDining ? 'Yes' : 'No'}</li>
                <li>Parking: {hotel.isParking ? 'Yes' : 'No'}</li>
                <li>Free WiFi: {hotel.isfreeWifi ? 'Yes' : 'No'}</li>
                <li>Room Service: {hotel.isRoomservice ? 'Yes' : 'No'}</li>
                <li>Swimming Pool: {hotel.isswimmingPool ? 'Yes' : 'No'}</li>
                <li>Fitness Center: {hotel.isFitnessCenter ? 'Yes' : 'No'}</li>
              </ul>
              
              <Link className="btn btn-info" to={`/availablerooms/${username}/${hotel.hotelId}`}>Rooms</Link>&nbsp;&nbsp;&nbsp;&nbsp;
              <Link className="btn btn-info" to={`/give-review/${username}/${hotel.hotelId}`}>Give Review</Link>
              
            </div>
          ))
        ) : (
          <p>No hotels available.</p>
        )}
      </div>
        </div>
    );
};

export default Hotelsearch;