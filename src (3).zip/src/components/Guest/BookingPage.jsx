import React, { useState } from 'react';
import GuestService from '../../Services/GuestService'; // Assuming this service handles booking API calls
import { Link, useNavigate, useParams } from 'react-router-dom';
import GuestSmallNav from './GuestSmallNav';
import './BookingPage.css'; 
import { useAuth } from '../../context/useAuth';
export const BookingPage = () => {
  const [numberOfPersons, setNumberOfPersons] = useState(0);
  const [numberOfAdults, setNumberOfAdults] = useState(0);
  const [numberOfChildren, setNumberOfChildren] = useState(0);
  const [numberOfRooms, setNumberOfRooms] = useState(1);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [totalPrice, setTotalPrice] = useState(null); // State to hold the total price
  const [errorMessage, setErrorMessage] = useState(''); // State to hold the error message
  const [isBookingConfirmed, setIsBookingConfirmed] = useState(false); // State to track booking confirmation
  const [reservationId, setReservationId] = useState(null); // State to hold the reservationId
  const { username, roomId,hotelId } = useParams(); 
  const navigate = useNavigate();
  const {auth}=useAuth();
    const token=auth.token;

  const reserveRoom = (e) => {
    e.preventDefault();
    const reservationObj = {
      numberOfPersons,
      numberOfAdults,
      numberOfChildren,
      numberOfRooms,
      startDate,
      endDate
    };
  
    GuestService.getGuestIdByUsername(username,token).then((responses) => {
      GuestService.reserveRoom(responses.data, roomId, reservationObj,token)
        .then((response) => {
          if (response.data && response.data.errorCode) {
            setErrorMessage(response.data.errorCode);
          } else {
            console.log("Room reserved", response);
            setErrorMessage('');
            setTotalPrice(response.data.totalPrice); // Set total price
            setIsBookingConfirmed(true); // Enable "Pay Now" button after booking confirmation
            setReservationId(response.data.reservationId); // Set reservationId from response
          }
        })
        .catch((error) => {
          console.error("Error while reserving room: ", error);
          if (error.response && error.response.data) {
            setErrorMessage(error.response.data.message); 
          } else {
            setErrorMessage('Room is already booked for that selected dates');
          }
        });
    }).catch((error) => {
      console.error("Error fetching guest ID: ", error);
      setErrorMessage('Error fetching guest details. Please try again later.');
    });
  };

 
  const handlePayment = () => {
    if (reservationId && totalPrice !== null) {
      navigate(`/payment/${username}/${reservationId}`, { state: { totalPrice } });
    } else {
      setErrorMessage('Unable to proceed with payment. Reservation ID or total price is missing.');
    }
  };
   
  return (
    <div>
      <GuestSmallNav/>
      <div id="bookback">
      <div className="container mt-4">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="Bookcard">
              <strong><h3 className="card-header">Book a Room</h3></strong>
              <div className="card-body">
                <form className="Bookform">
                  <div className="form-group mb-3">
                    <label htmlFor="inputNumberOfPersons" className="form-label">Number of Persons</label>
                    <input 
                      type="number" 
                      value={numberOfPersons} 
                      onChange={(e) => setNumberOfPersons(e.target.value)} 
                      className="form-control" 
                      id="inputNumberOfPersons"
                    />
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="inputNumberOfAdults" className="form-label">Number of Adults</label>
                    <input 
                      type="number" 
                      value={numberOfAdults} 
                      onChange={(e) => setNumberOfAdults(e.target.value)} 
                      className="form-control" 
                      id="inputNumberOfAdults"
                    />
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="inputNumberOfChildren" className="form-label">Number of Children</label>
                    <input 
                      type="number" 
                      value={numberOfChildren} 
                      onChange={(e) => setNumberOfChildren(e.target.value)} 
                      className="form-control" 
                      id="inputNumberOfChildren"
                    />
                  </div>

                  {/* <div className="form-group mb-3">
                    <label htmlFor="inputNumberOfRooms" className="form-label">Number of Rooms</label>
                    <input 
                      type="number" 
                      value={numberOfRooms} 
                      onChange={(e) => setNumberOfRooms(e.target.value)} 
                      className="form-control" 
                      id="inputNumberOfRooms"
                    />
                  </div> */}

                  <div className="form-group mb-3">
                    <label htmlFor="inputStartDate" className="form-label">Start Date</label>
                    <input 
                      type="date" 
                      value={startDate} 
                      onChange={(e) => setStartDate(e.target.value)} 
                      className="form-control" 
                      id="inputStartDate"
                      min={new Date().toISOString().split("T")[0]}
                    />
                  </div>

                  <div className="form-group mb-3">
                    <label htmlFor="inputEndDate" className="form-label">End Date</label>
                    <input 
                      type="date" 
                      value={endDate} 
                      onChange={(e) => setEndDate(e.target.value)} 
                      className="form-control" 
                      id="inputEndDate"
                      min={startDate}
                    />
                  </div>
                  
                  <div className="form-group d-flex justify-content-between">
                    <button onClick={(e) => reserveRoom(e)} className="btn btn-primary">Confirm</button>
                    <Link to={`/see-rooms/${username}/${hotelId}`} className="btn btn-danger">Cancel</Link>
                  </div>
                </form>

                {/* Display error message if room is unavailable or other errors occur */}
                {errorMessage && (
                  <div className="alert alert-danger mt-4">
                    {errorMessage}
                  </div>
                )}

                {/* Display total price after reservation */}
                {totalPrice !== null && (
                  <div className="mt-4">
                    <h5>Total Price: Rs.{totalPrice}</h5>
                  </div>
                )}

                {/* Pay Now button is disabled until booking is confirmed */}
                <div className="BookButton">
                  <button 
                    onClick={handlePayment} 
                    className="btn btn-primary"
                    disabled={!isBookingConfirmed} // Disable button until booking is confirmed
                  >
                    Pay Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
};

export default BookingPage;
