import React, { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import Select from 'react-select';
import { Button, Form, Container, Navbar, Image, NavDropdown } from 'react-bootstrap';
import { FaUserCircle, FaSearch } from 'react-icons/fa';
import GuestService from '../../Services/GuestService';
import 'react-datepicker/dist/react-datepicker.css';
import logoImage from '../images/cozyhavenlogo.jpg';
import Logout from '../Logout';
import { useAuth } from '../../context/useAuth';

export function GuestNavigation({ onSearch }) {
    const [location, setLocation] = useState(null);
    const [hotels, setHotels] = useState([]);
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(null);
    const { username } = useParams();
    const navigate = useNavigate(); // useNavigate for redirection
    const {auth}=useAuth();
    const token=auth.token;
    const handleSearch = (e) => {
        e.preventDefault();
        const selectedLocation = location ? location.value : null;
        const formattedStartDate = startDate ? formatDate(startDate) : null;
        const formattedEndDate = endDate ? formatDate(endDate) : null;

        console.log("Search parameters:", {
            location: selectedLocation,
            startDate: formattedStartDate,
            endDate: formattedEndDate
        });

        // Call the API
        GuestService.searchHotels(selectedLocation, formattedStartDate, formattedEndDate,token).then((response) => {
            console.log("hotels", response.data);
            setHotels(response.data);

            // Navigate to HotelResults page and pass the hotel data
            navigate(`/hotel-results/${username}`, { state: { hotels: response.data } });
        }).catch((error) => {
            console.error("Error fetching hotels", error);
        });
    };

    const formatDate = (date) => {
        const d = new Date(date);
        let month = '' + (d.getMonth() + 1);
        let day = '' + d.getDate();
        const year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    };

    return (
        <Navbar expand="lg">
            <Container fluid>
                <Navbar.Brand>
                    <Image src={logoImage} alt="CozyHavenLogo" height="50" width="50" />
                </Navbar.Brand>
                <Form className="d-flex w-75" onSubmit={handleSearch} style={{ maxWidth: '900px' }}>
                    <Select
                        className="me-2 flex-grow-1"
                        value={location}
                        onChange={(selectedOption) => setLocation(selectedOption)}
                        options={[
                            { value: 'chennai', label: 'Chennai' },
                            { value: 'Mumbai', label: 'Mumbai' },
                            { value: 'Hyderabad', label: 'Hyderabad' },
                            { value: 'Banglore', label: 'Banglore' },
                            { value: 'Goa', label: 'Goa' },
                            {value:'grandhotel',label:'grandhotel'},
                            {value:'Taj',label:'Taj'},
                            {value:'Pink Palace',label:'Pink Palace'},
                            {value:'Agoda',label:'Agoda'},
                            {value:'BangloreDays',label:'BangloreDays'},
                            {value:'SevenHills',label:'SevenHills'},
                            {value:'Crazystays',label:'Crazystays'},
                            {value:'Venky',label:'Venky'},
                            {value:'GloomyHotels',label:'GloomyHotels'}
                        ]}
                        placeholder="Select Location..."
                        isClearable
                    />
                    <DatePicker
                        selected={startDate}
                        onChange={(date) => setStartDate(date)}
                        selectsStart
                        startDate={startDate}
                        endDate={endDate}
                        minDate={new Date()}
                        placeholderText="Select Check-in Date"
                        className="form-control"
                    />&nbsp;&nbsp;
                    <DatePicker
                        selected={endDate}
                        onChange={(date) => setEndDate(date)}
                        selectsEnd
                        startDate={startDate}
                        endDate={endDate}
                        minDate={startDate}
                        placeholderText="Select Check-out Date"
                        className="form-control"
                    />&nbsp;&nbsp;
                    <Button type="submit" variant="outline-success">
                        <FaSearch />
                    </Button>
                </Form>
                <NavDropdown title={<FaUserCircle size={40} />} id="navbarScrollingDropdown" align="end">
                    {/* Add your dropdown items here */}
                    <NavDropdown.Item as={Link} to={`/myHistory/${username}`} >My Bookings</NavDropdown.Item>
                    <NavDropdown.Item><Logout/></NavDropdown.Item>
                </NavDropdown>
            </Container>
        </Navbar>
    );
}

export default GuestNavigation;
