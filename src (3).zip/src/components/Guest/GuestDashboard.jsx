import React, { useEffect, useState } from 'react';
import GuestService from '../../Services/GuestService';
import './Guest.css';
import { useNavigate, useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import GuestNavigation from './GuestNavigation'; // Import the GuestNavigation component
import { useAuth } from '../../context/useAuth';

export const GuestDashboard = () => {
  const [hotels, setHotels] = useState([]);
  const navigate = useNavigate();
  const { username } = useParams();
  const {auth}=useAuth();
  const token=auth.token;
  useEffect(() => {
    GuestService.getAllHotels(token)
      .then((response) => {
        console.log('data received from HOTELS' + JSON.stringify(response.data));
        const hotelsData = Array.isArray(response.data) ? response.data : JSON.parse(response.data);
        setHotels(hotelsData);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  // Placeholder function for search (you can remove this if not needed)
  const handleSearch = (location, startDate, endDate) => {
    console.log("Search function triggered with:", location, startDate, endDate);
    // Implement search logic or just leave this as a placeholder
  };

  return (
    <div className="guest-dashboard">
      {/* Include the GuestNavigation component */}
      <GuestNavigation onSearch={handleSearch} />

      <div className="hotel-grid">
        {hotels.length > 0 ? (
          hotels.map((hotel) => (
            <div key={hotel.hotelName} className="hotel-card">
              <img src={hotel.imageurl} alt={hotel.hotelName} className="hotel-image" />
              <h2>{hotel.hotelName}</h2>
              <p>{hotel.location}</p>
              <div className="hotel-rating">
                {[...Array(Math.floor(hotel.rating))].map((_, i) => (
                  <span key={i}>&#9733;</span> // Unicode for filled star
                ))}
              </div>
              <ul className="amenities">
                <li>Dining: {hotel.isDining ? 'Yes' : 'No'}</li>
                <li>Parking: {hotel.isParking ? 'Yes' : 'No'}</li>
                <li>Free WiFi: {hotel.isfreeWifi ? 'Yes' : 'No'}</li>
                <li>Room Service: {hotel.isRoomservice ? 'Yes' : 'No'}</li>
                <li>Swimming Pool: {hotel.isswimmingPool ? 'Yes' : 'No'}</li>
                <li>Fitness Center: {hotel.isFitnessCenter ? 'Yes' : 'No'}</li>
              </ul>
              
              <Link className="btn btn-info" to={`/see-rooms/${username}/${hotel.hotelId}`}>See rooms</Link>&nbsp;&nbsp;
              <Link className="btn btn-info" to={`/give-review/${username}/${hotel.hotelId}`}>Give Review</Link>
              
            </div>
          ))
        ) : (
          <p>No hotels available.</p>
        )}
      </div>
    </div>
  );
};

export default GuestDashboard;
