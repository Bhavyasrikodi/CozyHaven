import React, { useEffect, useState } from 'react';
import GuestService from '../../Services/GuestService';
import { useNavigate, useParams } from 'react-router-dom';
import GuestNavigation from './GuestNavigation';
import GuestSmallNav from './GuestSmallNav';
import { useAuth } from '../../context/useAuth';

export const MyGuestHistory = () => {
    const [reservations, setReservations] = useState([]);
    const { username } = useParams();
    const navigate = useNavigate();
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(() => {
        GuestService.getGuestIdByUsername(username,token)
            .then((response) => {
                GuestService.getBookingHistory(response.data,token)
                    .then((response) => {
                        console.log("History details", response.data);
                        setReservations(response.data);
                    })
                    .catch((error) => {
                        console.error("Error processing payment: ", error);
                    });
            })
            .catch((error) => {
                console.error("Error fetching guest ID: ", error);
            });
    }, [username]);

    const handleSearch = (location, startDate, endDate) => {
        console.log("Search function triggered with:", location, startDate, endDate);
        // Implement search logic or just leave this as a placeholder
    };

    const askForRefund = (reservationId) => {
        GuestService.getGuestIdByUsername(username,token).then((response) => {
            GuestService.requestRefund(reservationId,token)
                .then((response) => {
                    console.log("asked refund" + response.data);
                    navigate(`/myHistory/${username}`);
                })
                .catch((error) => {
                    console.log("error in requesting refund");
                });
        })
        .catch((error) => {
            console.error("Error fetching guest ID: ", error);
        });
    };

    const isRefundButtonDisabled = (startDate, reservationStatus) => {
        const currentDate = new Date();
        const reservationStartDate = new Date(startDate);
        // Disable if the current date is after or the same as start date or if the reservation is cancelled
        return currentDate >= reservationStartDate || reservationStatus === 'CANCELLED';
    };

    return (
        <div>
            <GuestSmallNav />
            <h2 className="text-center">My History</h2>
            <div className="table-responsive custom-table-container">
                <table className="table table-striped table-bordered table-hover custom-table">
                    <thead className="table-header">
                        <tr>
                            <th>Hotel Name</th>
                            <th>Location</th>
                            <th>Room Number</th>
                            <th>Bed Preferences</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Number of Persons</th>
                            <th>Reservation Status</th>
                            <th>Total Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {reservations.map((reservation) => (
                            <tr key={reservation.reservationId} className="table-row">
                                <td>{reservation.hotelName}</td>
                                <td>{reservation.location}</td>
                                <td>{reservation.roomNumber}</td>
                                <td>{reservation.bedPreferences}</td>
                                <td>{reservation.startDate}</td>
                                <td>{reservation.endDate}</td>
                                <td>{reservation.numberOfPersons}</td>
                                <td>{reservation.reservationStatus}</td>
                                <td>{reservation.totalPrice}</td>
                                <td>
                                    <button
                                        onClick={() => askForRefund(reservation.reservationId)}
                                        className="btn btn-primary"
                                        disabled={isRefundButtonDisabled(reservation.startDate, reservation.reservationStatus)}
                                    >
                                        Cancel Booking
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
