import React, { useState, useEffect } from 'react'; // Import useEffect
import { useParams } from 'react-router-dom';
import GuestService from '../../Services/GuestService';
import GuestSmallNav from './GuestSmallNav';
import './Review.css'; // Import the CSS file
import { useAuth } from '../../context/useAuth';

const StarRating = ({ rating, setRating }) => {
    const handleStarClick = (index) => {
        setRating(index + 1); // Stars are 1-indexed
    };

    return (
        <div className="star-rating">
            {[...Array(5)].map((star, index) => (
                <span
                    key={index}
                    className={`star ${index < rating ? 'filled' : ''}`}
                    onClick={() => handleStarClick(index)}
                >
                    &#9733;
                </span>
            ))}
        </div>
    );
};

export const Review = () => {
    const [rating, setRating] = useState(0);
    const [reviewText, setReviewText] = useState('');
    const [reviewDate, setReviewDate] = useState(''); // Initialize as empty string
    const [submitted, setSubmitted] = useState(false);
    const { username, hotelId } = useParams();
    const { auth } = useAuth();
    const token = auth.token;

    useEffect(() => {
        // Set the default review date to today
        const today = new Date().toISOString().split("T")[0]; // Get today's date in YYYY-MM-DD format
        setReviewDate(today); // Set state to today's date
    }, []); // Empty dependency array ensures this runs once on mount

    const handleSubmit = (e) => {
        e.preventDefault();

        const reviewObj = { rating, reviewText, reviewDate };

        GuestService.getGuestIdByUsername(username, token)
            .then((response) => {
                GuestService.rateNow(response.data, hotelId, reviewObj, token)
                    .then(() => {
                        setSubmitted(true); // Set the form as submitted
                    })
                    .catch((error) => {
                        console.error("Error processing review: ", error);
                    });
            })
            .catch((error) => {
                console.error("Error fetching guest ID: ", error);
            });
    };

    return (
        <div>
            <GuestSmallNav />
            <div id="reviewback">
                <div className="Reviewcontainer">
                    {submitted ? (
                        <div className="thank-you-message">
                            <h2>Thank you for your review!</h2>
                            <span role="img" aria-label="celebration" className="celebration-icon">🎉</span>
                        </div>
                    ) : (
                        <>
                            <h2>Leave your Review</h2>
                            <form onSubmit={handleSubmit} className="Reviewform">
                                <div className="Reviewform-group">
                                    <label>Username: {username}</label>
                                </div>

                                <div className="Reviewform-group">
                                    <label htmlFor="rating">Rating: </label>
                                    <StarRating rating={rating} setRating={setRating} />
                                </div>

                                <div className="Reviewform-group">
                                    <label htmlFor="reviewText">Review: </label>
                                    <textarea
                                        id="reviewText"
                                        value={reviewText}
                                        onChange={(e) => setReviewText(e.target.value)}
                                        required
                                    />
                                </div>

                                <div className="Reviewform-group">
                                    <label htmlFor="reviewDate">Review Date: </label>
                                    <input
                                        type="date"
                                        id="reviewDate"
                                        value={reviewDate}
                                        readOnly // Set the input to readOnly if you don't want it to be editable
                                        required
                                    />
                                </div>

                                <button type="submit">Submit Review</button>
                            </form>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Review;
