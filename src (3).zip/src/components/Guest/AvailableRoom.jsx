import React, { useState, useEffect } from 'react';
import GuestService from '../../Services/GuestService'; // Assuming this service will fetch room details
import './AvailableRoom.css'; // Style for your room grid and buttons

import { useNavigate, useParams } from 'react-router-dom';
import GuestSmallNav from './GuestSmallNav';
import { useAuth } from '../../context/useAuth';

const AvailableRoom = () => {
  const { hotelId } = useParams(); // Extract the hotel ID from the route
  const [rooms, setRooms] = useState([]);
  const{startDate,endDate}=useParams();
  const{username}=useParams();
  const {auth}=useAuth();
  const token=auth.token;

  useEffect(() => {
    // Fetch rooms based on the hotel ID
    GuestService.getRoomsByHotel(hotelId,token)
      .then((response) => {
        setRooms(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [hotelId]);
  
  useEffect(() => {
    GuestService.getAvailableRoomsByHotelLocation(hotelId, startDate, endDate,token)
      .then((response) => {
        setRooms(response.data);
      })
      .catch((error) => console.log(error));
  }, [hotelId, startDate, endDate]);

  return (
    <div>
        <GuestSmallNav/>
    <div className="rooms-grid">
        
      {rooms.length > 0 ? (
        rooms.map((room) => (
          <RoomCard key={room.roomNumber} room={room} />
        ))
      ) : (
        <p>No rooms available for this hotel.</p>
      )}
    </div>
    </div>
  );
};

// RoomCard component to display individual room details
const RoomCard = ({ room }) => {
    const [showDetails, setShowDetails] = useState(false);
    const navigate=useNavigate();
    const toggleDetails = () => setShowDetails(!showDetails);
  const{username,hotelId,roomId}=useParams();
    const handleBookRoom = () => {
      console.log("Booking Room: " + room.roomNumber);
      navigate(`/bookingPage/${username}/${hotelId}/${room.roomId}`);

    };
  
    return (
      <div
      
      className={`room-card ${room.availability ? 'available' : 'booked'}`}
        onClick={toggleDetails}
      >
        <img src={room.roomimageurl} alt={room.roomNumber} className="room-image" />
        
        <h3>Room {room.roomNumber}</h3>
        <p>{room.bedPreferences}</p>
        <p>Status: {room.availability ? 'Available' : 'Booked'}</p>

        {showDetails && (
          <div className="availableroom-details">
            <p>Base Fare: Rs.{room.baseFare}</p>
            <p>Max Occupancy: {room.maxOccupancy} people</p>
            <p>AC: {room.isAc ? 'Yes' : 'No'}</p>
          </div>
        )}
  
        {room.availability && (
          <button className="availablebtn-book" onClick={handleBookRoom}>
            Book Now
          </button>
        )}
      </div>
    );
  };

export default AvailableRoom;