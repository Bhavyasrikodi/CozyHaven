import React, { useState } from 'react';
import AuthService from '../Services/AuthService';
import { useNavigate } from 'react-router-dom';
import './Registration.css';

const Registration = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState("");
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    email: "",
    phoneNumber: "",
    adminName: "",
    adminLevel: "",
    guestName: "",
    gender: "",
    guestAddress: "",
    aadharNumber: "",
    hotelOwnerName: "",
    businessLicense: ""
  });

  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [phoneError, setPhoneError] = useState(""); // State for phone number error

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));

    // Clear phone number error when user types
    if (name === 'phoneNumber') {
      setPhoneError("");
    }
  };

  const validateForm = () => {
    const { username, password, email, phoneNumber } = formData;
    setError("");

    // Username validation
    if (!username) {
      setError("Username is required.");
      return false;
    }
    if (username.length < 3) {
      setError("Username must be at least 3 characters long.");
      return false;
    }

    // Password validation
    if (!password) {
      setError("Password is required.");
      return false;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return false;
    }
    // const passwordRegex = /^(?=.[A-Z])(?=.\d)/; // At least one uppercase letter and one number
    // if (!passwordRegex.test(password)) {
    //   setError("Password must contain at least one uppercase letter and one number.");
    //   return false;
    // }

    // Email validation
    // const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // if (!email) {
    //   setError("Email is required.");
    //   return false;
    // }
    // if (!emailRegex.test(email)) {
    //   setError("Invalid email format.");
    //   return false;
    // }

    // Phone number validation
    const phoneRegex = /^\d{10}$/; // Assuming a 10-digit phone number
    if (!phoneNumber) {
      setPhoneError("Phone number is required.");
      return false;
    }
    if (!phoneRegex.test(phoneNumber)) {
      setPhoneError("Phone number must be exactly 10 digits.");
      return false;
    }

    return true;
  };

  const saveUserRegistration = (e) => {
    e.preventDefault();

    // Validate the form before submission
    if (!validateForm()) {
      return;
    }

    const userRegistrationObj = {
      username: formData.username,
      password: formData.password,
      role: role,
      ...formData,
    };

    AuthService.registerUser(userRegistrationObj)
      .then((response) => {
        setSuccess(true);
        if (response.data === "username already exists") {
          window.alert("Username already exists");
        } else {
          navigate('/login');
        }
      })
      .catch((error) => {
        if (!error?.response) {
          setError("No server response");
        } else if (error.response?.status === 409) {
          setError("Username taken");
        } else {
          setError("Registration failed");
        }
      });
  };

  return (
    <div className="registration-container">
      <form onSubmit={saveUserRegistration}>
        <h1>Register Now</h1>
        <label htmlFor="role">Select Role:</label>
        <select name="role" value={role} onChange={(e) => setRole(e.target.value)} required>
          <option value="">--Select Role--</option>
          <option value="ADMIN">Admin</option>
          <option value="GUEST">Guest</option>
          <option value="HOTEL_OWNER">Hotel Owner</option>
        </select>

        <br />
        <label htmlFor="username">Username:</label>
        <input type="text" name="username" value={formData.username} onChange={handleChange} required />
        <br />

        <label htmlFor="password">Password:</label>
        <input type="password" name="password" value={formData.password} onChange={handleChange} required />
        <br />

        <label htmlFor="email">Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} required />
        <br />

        <label htmlFor="phoneNumber">Phone Number:</label>
        <input type="text" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} required />
        <br />
        {phoneError && <p className="error">{phoneError}</p>} {/* Display phone number error */}

        {role === 'ADMIN' && (
          <>
            <label htmlFor="adminName">Admin Name:</label>
            <input type="text" name="adminName" value={formData.adminName} onChange={handleChange} />
            <br />

            <label htmlFor="adminLevel">Admin Level:</label>
            <input type="text" name="adminLevel" value={formData.adminLevel} onChange={handleChange} />
            <br />
          </>
        )}

        {role === 'GUEST' && (
          <>
            <label htmlFor="guestName">Guest Name:</label>
            <input type="text" name="guestName" value={formData.guestName} onChange={handleChange} />
            <br />

            <label htmlFor="gender">Gender:</label>
            <input type="text" name="gender" value={formData.gender} onChange={handleChange} />
            <br />

            <label htmlFor="guestAddress">Guest Address:</label>
            <input type="text" name="guestAddress" value={formData.guestAddress} onChange={handleChange} />
            <br />

            <label htmlFor="aadharNumber">Aadhar Number:</label>
            <input type="text" name="aadharNumber" value={formData.aadharNumber} onChange={handleChange} />
            <br />
          </>
        )}

        {role === 'HOTEL_OWNER' && (
          <>
            <label htmlFor="hotelOwnerName">Hotel Owner Name:</label>
            <input type="text" name="hotelOwnerName" value={formData.hotelOwnerName} onChange={handleChange} />
            <br />

            <label htmlFor="businessLicense">Business License:</label>
            <input type="text" name="businessLicense" value={formData.businessLicense} onChange={handleChange} />
            <br />
          </>
        )}

        <button type="submit">Register</button>
      </form>

      {error && <p className="error">{error}</p>}
      {success && <p className="success">Registration successful!</p>}
    </div>
  );
};

export default Registration;