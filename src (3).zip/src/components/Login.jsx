import React, { useContext, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck, faTimes } from '@fortawesome/free-solid-svg-icons';
import AuthService from '../Services/AuthService';
import { AuthContext } from '../context/AuthProvider';
import './Registration.css';
const USER_REGEX = /^[a-zA-Z][a-zA-Z0-9-_]{3,23}$/;

export const Login = () => {
    const userRef = useRef();
    const errorRef = useRef();
    const [username, setUsername] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [roles, setRole] = React.useState('');
    const [error, setError] = React.useState('');
    const [validName, setValidName] = React.useState(false);
    const { setAuth } = useContext(AuthContext);
    const navigate = useNavigate();
    const location = useLocation();
    const from = location.state?.from?.pathname || '/';
    

    useEffect(() => {
        userRef.current.focus();
    }, []);

    useEffect(() => {
        const result = USER_REGEX.test(username);
        setValidName(result);
        setError('');
    }, [username, password]);

    const loginUser = (e) => {
        e.preventDefault();

        const userLoginObj = { username, password, roles };
        AuthService.loginUser(userLoginObj)
            .then((response) => {
                console.log("loginpage"+JSON.stringify(response.data))
                const { token, username, role } = response.data;

                setAuth({
                    role,
                    token,
                    username,
                });

                // Redirect based on the role
                if (roles === 'ADMIN'&& role==='ADMIN') {
                    console.log("admin")
                    navigate('/admin-displayhotels');
                } else if (roles === 'GUEST'&& role==='GUEST') {
                    console.log("guest")
                    navigate(`/guest-dashboard/${username}`);
                } else if (roles === 'HOTEL_OWNER'&& role==='HOTEL_OWNER') {
                    console.log("owner")
                    navigate(`/hotelnav/${username}`);
                } else {
                    window.alert("Wrong Credentials")
                    navigate(from, { replace: true });

                }
            })
            .catch((error) => {
                if (!error?.response) {
                    setError('No server response');
                } else if (error.response?.status === 500) {
                    setError('Bad Credentials');
                } else {
                    setError('Login failed');
                }
            });
    };

    return (
        <div id="background">
            <section>
                <p ref={errorRef} className={error ? 'errmsg' : 'offscreen'} aria-live="assertive">
                    {error}
                </p>
                
                <form>
                <h1>Sign In</h1>
                    {/* USERNAME */}
                    <label htmlFor="username"> Username</label>
                    {/* <span className={validName && username ? 'valid' : 'hide'}>
                        <FontAwesomeIcon icon={faCheck} />
                    </span>
                    <span className={validName || !username ? 'hide' : 'invalid'}>
                        <FontAwesomeIcon icon={faTimes} />
                    </span> */}
                    <input
                        type="text"
                        ref={userRef}
                        autoComplete="off"
                        onChange={(e) => setUsername(e.target.value)}
                        value={username}
                        required
                    />

                    {/* PASSWORD */}
                    <label htmlFor="password"> Password</label>
                    <input
                        type="password"
                        onChange={(e) => setPassword(e.target.value)}
                        value={password}
                        required
                    />

                    {/* ROLE (if not included in the login API) */}
                    {/* Uncomment if you need role selection in the form */}
                    
                    <label htmlFor="role">Role:</label>
                    <select onChange={(e) => setRole(e.target.value)} value={roles} required>
                        <option value="">Select Role</option>
                        <option value="ADMIN">Admin</option>
                        <option value="GUEST">Guest</option>
                        <option value="HOTEL_OWNER">HotelOwner</option>
                    </select> 
                   

                    <button onClick={(e) => loginUser(e)}>Login</button>

                    <p>Need an account?</p>
                    <span className="line">
                        <a href="/register">Sign UP</a>
                    </span>
                </form>
            </section>
        </div>
    );
};
