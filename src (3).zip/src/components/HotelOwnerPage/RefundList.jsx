import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import HotelOwnerService from '../../Services/HotelOwnerService';
import { HotelOwnerNavigation } from './HotelOwnerNavigation';
import { useAuth } from '../../context/useAuth';

export const RefundList = () => {
    const [payments, setPayments] = useState([]);
    const { username } = useParams();
    const {auth}=useAuth();
    
    const token=auth.token;
    useEffect(() => {
        console.log("useEffect fired");
        HotelOwnerService.findHotelIdByUsername(username,token).then((responses) => {
            console.log("response data=" + responses.data);
            HotelOwnerService.getRefundList(responses.data,token).then((response) => {
                if (Array.isArray(response.data)) {
                    setPayments(response.data); // Ensure it's an array
                } else {
                    setPayments([]); // Set as empty array if the response is not an array
                }
                console.log("data received from getRefundList" + JSON.stringify(response.data));
            }).catch((error) => {
                console.log(error);
                setPayments([]); // Handle error by setting an empty array
            });
        });
    }, [username]);
    
    const Refunded = (paymentId) => {
        HotelOwnerService.sendRefund(paymentId,token).then((response) => {
            window.alert("Amount Refunded Successfully.")
        });
    };

    return (
        <div>
            <HotelOwnerNavigation />
            <div className='container'>
                <h2 className="text-center">Refund List</h2>
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Amount</th>
                            <th>Payment Date</th>
                            <th>Payment Status</th>
                            <th>Guest Id</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {/* Check if payments is a non-empty array */}
                        {payments.length > 0 ? (
                            payments.map((payment, key) => (
                                <tr key={key}>
                                    <td>{payment[1]}</td>
                                    <td>{payment[2]}</td>
                                    <td>{payment[3]}</td>
                                    <td>{payment[4]}</td>
                                    <td> <button onClick={() => Refunded(payment[0])} className="btn btn-danger">Refund</button></td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4" className="text-center">No payments found</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
