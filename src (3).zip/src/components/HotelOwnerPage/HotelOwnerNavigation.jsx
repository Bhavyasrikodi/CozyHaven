import React, { useEffect } from 'react'
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Image } from 'react-bootstrap';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { FaUserCircle } from 'react-icons/fa';
import logo from '../images/cozyhavenlogo.jpg';
import Logout from '../Logout';
import { useParams } from 'react-router-dom';
import { Link} from 'react-router-dom';
export const HotelOwnerNavigation = () => {
  const {username}=useParams();

  useEffect(()=>{
    
},[username])
  return (
    <div>
         <Navbar expand="lg" className="bg-body-tertiary">
      <Container fluid>
      <Navbar.Brand>
          <Image src={logo}
           alt="CozyHavenLogo" height="50" width="50"/>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" 
        onError={(e) => {
          console.error("Error loading image:", e);
          e.target.src = 'https://via.placeholder.com/150?text=CozyHaven'; // Fallback image
        }}
        />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link as={Link} to={`/hotel-guests/`+username}>Guests</Nav.Link>
            <Nav.Link as={Link} to={`/hotel-reservations/`+username}>Reservations</Nav.Link>
            <Nav.Link as={Link} to={`/hotel-rooms/`+username}>Rooms</Nav.Link> 
            <Nav.Link as={Link} to={`/my-hotel/`+username}>My Hotel</Nav.Link>
            <Nav.Link as={Link} to={`/reviews/`+username}>Reviews</Nav.Link>
            <Nav.Link as={Link} to={`/refund/`+username}>Refund List</Nav.Link> 
            
          </Nav>
          
          <NavDropdown 
              title={<FaUserCircle size={40} />} 
              id="navbarScrollingDropdown"
              align="end"
            >
          <NavDropdown.Item as={Link} to={`/add-hotel/`+username}>Add Hotel</NavDropdown.Item>
          <NavDropdown.Item  id="navbarScrollingDropdown"><Logout/></NavDropdown.Item>
          </NavDropdown>
     
        </Navbar.Collapse>
          </Container>
       </Navbar>

    </div>
  )
}