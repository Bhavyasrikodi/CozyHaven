import React, { useEffect, useState } from 'react'
import HotelOwnerService from '../../Services/HotelOwnerService'
import { useParams } from 'react-router-dom'
import { HotelOwnerNavigation } from './HotelOwnerNavigation'
import { useAuth } from '../../context/useAuth'

export const DisplayHotelGuests = () => {
    const[guests,setGuests]=useState([])
    const {username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(()=>{
        console.log("useeffect fired")
        HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
          console.log("response data="+responses.data)

        HotelOwnerService.getGuestsOfHotel(responses.data,token).then((response)=>{
            console.log("data recevied from getGuestsOfHotel"+JSON.stringify(response.data))
            setGuests(response.data)
        }).catch((error)=> {
            console.log(error);
          })
          .finally(()=> {
            // always executed
          });
        })     
    },[username])
  return (
    <div>
      <HotelOwnerNavigation/>
    <div className='container'>
       <h2 className="text-center">Hotel Guests</h2>
       <table className="table table-bordered table-striped">
            <thead>
                <th>Guest Id</th>
                <th> Name</th>
                <th> Email</th>
                <th> Address</th>
                <th>Gender</th>
                <th>Phone Number</th>
                <th>Aadhar Number</th>
            </thead>
            <tbody>
              {guests.map((guests,key)=>
              <tr>
                <td>{guests.guestId}</td>
                <td>{guests.guestName}</td>
                <td>{guests.email}</td>
                <td>{guests.guestAddress}</td>
                <td>{guests.gender}</td>
                <td>{guests.phoneNumber}</td>
                <td>{guests.aadharNumber}</td>
              </tr>)}
            </tbody>
        </table>
    </div>
</div>
  )
}