import React, { useEffect, useState } from 'react'
import HotelOwnerService from '../../Services/HotelOwnerService'
import { useParams } from 'react-router-dom'
import { HotelOwnerNavigation } from './HotelOwnerNavigation'
import { useAuth } from '../../context/useAuth'
export const MyHotelReviews = () => {
    const [reviews,setReviews] = useState([])
    const {username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(()=>{
      console.log("useeffect fired")
      HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
        console.log("response data="+responses.data)
        HotelOwnerService.getReviews(responses.data,token).then((response)=>{
          console.log("data recevied from getReservationsOfHotel"+JSON.stringify(response.data))
          setReviews(response.data)
      }).catch((error)=> {
          console.log(error);
        })
        .finally(()=> {
          // always executed
        });
      })     
  },[username])
  return (
    <div>

  <HotelOwnerNavigation/>
    <div className='container'>
        <h2 className="text-center">Hotel Reviews</h2>
        <table className="table table-bordered table-striped">
            <thead>
                <th>Guest Id</th>
                <th> Rating</th>
                <th>Review Text</th>
                
            </thead>
            <tbody>
              {reviews.map((reviews,key)=>
              <tr>
                <td>{reviews[2]}</td>
                <td>{reviews[0]}</td>
                <td>{reviews[1]}</td>
                
              </tr>)}
            </tbody>
        </table>

    </div>
</div>
  )
}