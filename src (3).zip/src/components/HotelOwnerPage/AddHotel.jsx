import React from 'react'

import { useNavigate, useParams } from 'react-router-dom';
import { useEffect } from 'react';
import HotelOwnerService from '../../Services/HotelOwnerService';
import { HotelOwnerNavigation } from './HotelOwnerNavigation';
import { useAuth } from '../../context/useAuth';
import './Hotel.css';

export const AddHotel = () => {
    const[hotelName,setHotelName]=React.useState('');
    const[location,setLocation]=React.useState('');
    const[isDining,setDining]=React.useState(false);
    const[isParking,setParking]=React.useState(false);
    const[isfreeWifi,setFreeWifi]=React.useState(false);
    const[isRoomservice,setRoomService]=React.useState(false);
    const[isswimmingPool,setSwimmingPool]=React.useState(false);
    const[isFitnessCenter,setFitnessCenter]=React.useState(false);
    const[imageurl,setImageurl]=React.useState('');
    const[rating,setRating]=React.useState('');
    const[ownerId,setOwnerId]=React.useState('');
    const navigate=useNavigate();
    const {username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    const{ownerid,hotelId}=useParams();
    const changeTitle=()=>{
        if(hotelId){
          return <h2 className="text-center">Update Hotel</h2>
        }
        else{
          return <h2 className="text-center">Add Hotel</h2>
        }
      }

    useEffect(()=>{
        console.log("useEffect fired...")
        
        if(hotelId){
            
            HotelOwnerService.findByHotelId(hotelId,token).then((response)=>{
                const hotel = response.data;
                setHotelName(hotel.hotelName);
                setLocation(hotel.location);
                setDining(hotel.isDining);
                setParking(hotel.isParking);
                setFreeWifi(hotel.isfreeWifi);
                setRoomService(hotel.isRoomservice);
                setSwimmingPool(hotel.isswimmingPool);
                setFitnessCenter(hotel.isFitnessCenter);
                setImageurl(hotel.imageurl);
                setRating(hotel.rating);
            }).catch((error)=>{
                console.error("Error fetching hotel details:", error);
            })
        }
        
        },[hotelId])

        const saveOrUpdateHotel = (e) => {
            e.preventDefault();
            
            HotelOwnerService.getOwnerid(username,token).then((response)=>{
                const ownerId=response.data;
                const hotelObj = {hotelName, location, isDining, isParking, isfreeWifi, isRoomservice, isswimmingPool, isFitnessCenter, imageurl,rating,ownerId};
            
            if (hotelId) {
                HotelOwnerService.updateHotelbyOwnerId(hotelObj, hotelId, ownerId,token).then(
                    (response) => {
                        console.log("Hotel updated successfully:", response.data);
                        navigate(`/hotel-rooms/${username}`);
                    }
                ).catch((error) => {
                    console.error("Error updating hotel:", error);
                });
            } else {
                HotelOwnerService.saveHotel(hotelObj,token).then(
                    (response) => {
                        console.log("New hotel saved:", response.data);
                        navigate(`/my-hotel/${username}`);
                    }
                ).catch((error) => {
                    console.error("Error saving new hotel:", error);
                });
            }
            })
            
        };

    

    return (
        <div>
            <HotelOwnerNavigation/>
            <div id="hotelback">
            <div className="container mt-4">
                <div className="row justify-content-center">
                    <div className="col-md-6">
                        <div className="card">
                        {changeTitle()}
                            <div className='card-body'>
                                <h5>Note:One Owner should contain only one Hotel!!!</h5>
                                
                                <div className="d-flex justify-content-center align-items-center" style={{ height: "100vh" }}>
                                <form>
                                    <div className="form-group mb-3">
                                        <label htmlFor="inputHotelName" className="form-label">Hotel Name</label>
                                        <input 
                                            type="text" 
                                            value={hotelName} 
                                            onChange={(e) => setHotelName(e.target.value)} 
                                            className="form-control" 
                                            id="inputHotelName"
                                        />
                                    </div>
                                    <div className="form-group mb-3">
                                        <label htmlFor="inputLocation" className="form-label">Location</label>
                                        <input 
                                            type="text" 
                                            value={location} 
                                            onChange={(e) => setLocation(e.target.value)}  
                                            className="form-control" 
                                            id="inputLocation"
                                        />
                                    </div>
                                    <div className="form-group mb-3">
                                        <label htmlFor="inputimageurl" className="form-label">Image url</label>
                                        <input 
                                            type="text" 
                                            value={imageurl} 
                                            onChange={(e) => setImageurl(e.target.value)} 
                                            className="form-control" 
                                            id="inputimageurl"
                                        />
                                    </div>
                                    <div className="form-group mb-3">
                                        <label htmlFor="inputRating" className="form-label">Rating</label>
                                        <input 
                                            type="text" 
                                            value={rating} 
                                            onChange={(e) => setRating(e.target.value)} 
                                            className="form-control" 
                                            id="inputRating"
                                        />
                                    </div>
                                    {/* <div className="form-check mb-3">
                                    <label className="form-label" htmlFor="inputOwnerId">OwnerId</label>
                                        <input 
                                            type="number" 
                                            value={ownerId} 
                                            onChange={(e) => setOwnerId(e.target.value)} 
                                            className="form-control" 
                                            id="inputOwnerId"
                                        />
                                    </div> */}
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isDining} 
                                            onChange={(e) => setDining(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputDining"
                                        />
                                        <label className="form-check-label" htmlFor="inputDining">Dining Available</label>
                                    </div>
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isParking} 
                                            onChange={(e) => setParking(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputParking"
                                        />
                                        <label className="form-check-label" htmlFor="inputParking">Parking Available</label>
                                    </div>
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isfreeWifi} 
                                            onChange={(e) => setFreeWifi(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputFreeWifi"
                                        />
                                        <label className="form-check-label" htmlFor="inputFreeWifi">Free WiFi</label>
                                    </div>
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isRoomservice} 
                                            onChange={(e) => setRoomService(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputRoomService"
                                        />
                                        <label className="form-check-label" htmlFor="inputRoomService">Room Service</label>
                                    </div>
                                    
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isswimmingPool} 
                                            onChange={(e) => setSwimmingPool(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputSwimmingPool"
                                        />
                                        <label className="form-check-label" htmlFor="inputSwimmingPool">Swimming Pool</label>
                                    </div>
                                    <div className="form-check mb-3">
                                        <input 
                                            type="checkbox" 
                                            checked={isFitnessCenter} 
                                            onChange={(e) => setFitnessCenter(e.target.checked)} 
                                            className="form-check-input" 
                                            id="inputFitnessCenter"
                                        />
                                        <label className="form-check-label" htmlFor="inputFitnessCenter">Fitness Center</label>
                                    </div>
                                    <div className="form-group d-flex justify-content-between">
                                        <button onClick={(e) => saveOrUpdateHotel(e)} className="btn btn-primary">Save</button>
                                        <button onClick={() => navigate('/admin-displayhotels')} className="btn btn-danger">Cancel</button>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    )
}