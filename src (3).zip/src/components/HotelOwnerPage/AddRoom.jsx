import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import HotelOwnerService from '../../Services/HotelOwnerService';
import { HotelOwnerNavigation } from './HotelOwnerNavigation';
import { useAuth } from '../../context/useAuth';

import './Hotel.css';

export const AddRoom = () => {
    const [availability,setAvailability]=React.useState(false);
    const [baseFare,setBasefare]=React.useState('');
    const [bedPreferences,SetBedPreference]=React.useState('');
    const [isAc,setAc]=React.useState(false);
    const [maxOccupancy,setMaxOccupancy]=React.useState('');
    const [roomNumber,setroomNumber]=React.useState('');
    const[roomimageurl,setRoomImageurl]=React.useState('');
    const navigate=useNavigate();
    const {roomId,username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    const changeTitle=()=>{
      if(roomId){
        return <h2 className="text-center">Update Room</h2>
      }
      else{
        return <h2 className="text-center">Add Room</h2>
      }
    }
    useEffect(()=>{
      console.log("useeffect fired")
       if(roomId){
         console.log("id received from url"+roomId)
          HotelOwnerService.findById(roomId,token).then(
           (response)=>{
             console.log("response from findById()"+JSON.stringify(response.data))
             setAc(response.data.isAc)
             setAvailability(response.data.availability)
             setBasefare(response.data.baseFare)
             setMaxOccupancy(response.data.maxOccupancy)
             setroomNumber(response.data.roomNumber)
             setRoomImageurl(response.data.roomimageurl)
             SetBedPreference(response.data.bedPreferences)
           })
       }
     },[roomId,username])

    const saveOrUpdateRoom = (e) => {
      console.log("save or update method fired")
      console.log("username="+username+"roomId"+roomId)
        e.preventDefault();
        const roomObj = {roomNumber,baseFare: parseFloat(baseFare),
          maxOccupancy: parseInt(maxOccupancy),isAc,availability,roomimageurl,bedPreferences};
        
        if (roomId) {
          console.log("if")
            HotelOwnerService.updateRoom(roomObj,roomId,token).then(
                (response) => {
                    console.log("Room updated successfully:", response.data);
                    console.log("username"+username)
                    navigate(`/hotel-rooms/${username}`);
                }
            ).catch((error) => {
                console.error("Error updating room:", error);
            });
        } else if(username) {
          console.log("enntered into else if")
          HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
            console.log("response data from service="+responses.data)
            HotelOwnerService.saveRoom(roomObj,responses.data,token).then(
                (response) => {
                    console.log("New room saved:", response.data);
                    navigate(`/hotel-rooms/${username}`);
                }
            ).catch((error) => {
                console.error("Error saving new room:", error);
            });
          })
        }
    };
  return (
<div>
  <HotelOwnerNavigation/>
  <div id="hotelback">
    <div className="container">
      
    <div className='card col-md-6 offset-md-3'>
    {changeTitle()} 
    
    <div className="d-flex justify-content-center align-items-center" style={{ height: "120vh" }}>
     
    <form class="row g-3">
         <div className="form-check mb-3">
         <input 
           type="checkbox" 
           checked={availability} 
           onChange={(e) => setAvailability(e.target.checked)} 
           className="form-check-input" 
           id="inputAvailability"
           />
           <label className="form-check-label" htmlFor="inputAvailability">Room Availability</label>
        </div>
        <div className="form-check mb-3">
          <label className="form-label" htmlFor="inputBasefare">Base Fare</label>
        <input 
           type="number" 
           value={baseFare} 
           onChange={(e) => setBasefare(e.target.value)} 
           className="form-control" 
           id="inputBasefare"
           />
        </div>
        <div className="form-check mb-3">
        <label className="form-label" htmlFor="inpurBedPreference">Bed Preference</label>
          <select
            name="bedPreferences"
            value={bedPreferences}
            onChange={(e)=>SetBedPreference(e.target.value)}
          >
            <option>Select</option>
            <option value="SINGLE">Single</option>
            <option value="DOUBLE">Double</option>
            <option value="KING">King</option>
          </select>
      </div>
      <div className="form-check mb-3">
         <input 
           type="checkbox" 
           checked={isAc} 
           onChange={(e) => setAc(e.target.checked)} 
           className="form-check-input" 
           id="inputAc"
           />
           <label className="form-check-label" htmlFor="inputAc">Ac</label>
        </div>
        <div className="form-check mb-3">
          <label className="form-label" htmlFor="inputMaxOccupamcy">Max Occupancy</label>
        <input 
           type="text" 
           value={maxOccupancy} 
           onChange={(e) => setMaxOccupancy(e.target.value)} 
           className="form-control" 
           id="inputMaxOccupamcy"
           />
        </div>
        <div className="form-check mb-3">
          <label className="form-label" htmlFor="inputRoomNumber">Room Number</label>
        <input 
           type="text" 
           value={roomNumber} 
           onChange={(e) => setroomNumber(e.target.value)} 
           className="form-control" 
           id="inputRoomNumber"
           />
        </div>
    
        <div className="form-group mb-3">
          <label htmlFor="inputimageurl" className="form-label">Image url</label>
        <input 
          type="text" 
          value={roomimageurl} 
          onChange={(e) => setRoomImageurl(e.target.value)} 
          className="form-control" 
          id="inputimageurl"
          />
        </div>
        <div className="form-group d-flex justify-content-between">
            <button onClick={(e) => saveOrUpdateRoom(e)} className="btn btn-primary">Save</button>
            <button onClick={() => navigate(`/hotel-rooms/${username}`)} className="btn btn-danger">Cancel</button>
        </div>

</form>
</div>
</div>
</div>
</div>
</div>
  )
}
