import React from 'react'
import { HotelOwnerNavigation } from './HotelOwnerNavigation'
import { DisplayHotelReservations } from './DisplayHotelReservations'

export const HotelOwerDashboard = () => {
  return (
    <div>
        <DisplayHotelReservations/>
    </div>
  )
}