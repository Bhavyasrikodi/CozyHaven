import React, { useEffect, useState } from 'react'
import HotelOwnerService from '../../Services/HotelOwnerService'
import { useParams } from 'react-router-dom'
import { HotelOwnerNavigation } from './HotelOwnerNavigation'
import { useAuth } from '../../context/useAuth'
export const DisplayHotelReservations = () => {
    const [reservations,setReservations] = useState([])
    const {username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(()=>{
      console.log("useeffect fired")
      HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
        console.log("response data="+responses.data)
        HotelOwnerService.getReservationsOfHotel(responses.data,token).then((response)=>{
          console.log("data recevied from getReservationsOfHotel"+JSON.stringify(response.data))
          setReservations(response.data)
      }).catch((error)=> {
          console.log(error);
        })
        .finally(()=> {
          // always executed
        });
      })     
  },[username])
  return (
    <div>

  <HotelOwnerNavigation/>
    <div className='container'>
        <h2 className="text-center">Hotel Reservations</h2>
        <table className="table table-bordered table-striped">
            <thead>
                <th>Reservation Id</th>
                <th>Romm Id</th>
                <th>Guest Id</th>
                <th>Number of Persons</th>
                <th>Check-in Date</th>
                <th>Check-out Date</th>
                <th>Total Price</th>
                <th>Booking Status</th>
            </thead>
            <tbody>
              {reservations.map((reservations,key)=>
              <tr>
                <td>{reservations.reservationId}</td>
                <td>{reservations.roomId}</td>
                <td>{reservations.guestId}</td>
                <td>{reservations.numberOfPersons}</td>
                <td>{reservations.startDate}</td>
                <td>{reservations.endDate}</td>
                <td>{reservations.totalPrice}</td>
                <td>{reservations.reservationStatus}</td>
              </tr>)}
            </tbody>
        </table>

    </div>
</div>
  )
}