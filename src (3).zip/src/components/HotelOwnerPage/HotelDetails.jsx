import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import HotelOwnerService from '../../Services/HotelOwnerService'
import { HotelOwnerNavigation } from './HotelOwnerNavigation'
import { useAuth } from '../../context/useAuth'

export const HotelDetails = () => {
    const [hotel, setHotel] = useState(null)
    const [error, setError] = useState(null)
    const { username } = useParams();
    const {auth}=useAuth();
    const token=auth.token;
    useEffect(() => {
        HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
            console.log("response data of hotel="+responses.data)
        HotelOwnerService.findByHotelId(responses.data,token)
            .then((response) => {
                setHotel(response.data)
            })
            .catch((error) => {
                console.error("Error fetching hotel details:", error);
                setError("Failed to fetch hotel details. Please try again later.")
            });
        })
    }, [username])

    if (error) {
        return <div className="alert alert-danger">{error}</div>
    }

    if (!hotel) {
        return <div>Loading...</div>
    }

    return (
        <div>
            <HotelOwnerNavigation/>
        <div className="container" >
            <h2 className="text-center">My Hotel</h2>
            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Hotel Name</th>
                        <th>Location</th>
                        <th>Is Dining</th>
                        <th>Is Parking</th>
                        <th>Is FreeWifi</th>
                        <th>Is RoomService</th>
                        <th>Is SwimmingPool</th>
                        <th>Is FitnessCenter</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{hotel.hotelName}</td>
                        <td>{hotel.location}</td>
                        <td>{hotel.isDining?'Yes' : 'No'}</td>
                        <td>{hotel.isParking?'Yes' : 'No'}</td>
                        <td>{hotel.isfreeWifi?'Yes' : 'No'}</td>
                        <td>{hotel.isRomservice?'Yes' : 'No'}</td>
                        <td>{hotel.isswimmingPool?'Yes' : 'No'}</td>
                        <td>{hotel.isFitnessCenter?'Yes' : 'No'}</td>
                        <td>
                            <Link to={`/add-room/${username}`} className="btn btn-primary">
                                Add Room
                            </Link>
                        </td>
                    </tr>
                </tbody>
                <br></br>
                 
            </table>
        </div>
      </div>
    )
}