import React, { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom';
import HotelOwnerService from '../../Services/HotelOwnerService';
import { Nav } from 'react-bootstrap';
import { HotelOwnerNavigation } from './HotelOwnerNavigation';
import { useAuth } from '../../context/useAuth';

export const DisplayHotelRooms = () => {
    const [rooms,setRooms]=useState([])
    const [deleteStatus,setdeleteStatus]=useState([false])
    const navigate=useNavigate();
    const {username}=useParams();
    const {auth}=useAuth();
    const token=auth.token;
    const deleteRoom=(roomId)=>{
      console.log("Room Id received from event handler "+roomId)
      //console.log("OwnerId"+ownerId)
    
      HotelOwnerService.deleteRoom(roomId,token).then(
          (response)=>{
              console.log("data receibed from deleteRoom"+JSON.stringify(response.data))
              setdeleteStatus(!deleteStatus)
              navigate(`/hotel-rooms/${username}`)
          }
      )
  }
    useEffect(()=>{
        console.log("useeffect fired in display hotel rooms")
        HotelOwnerService.findHotelIdByUsername(username,token).then((responses)=>{
          console.log("response data="+responses.data)
        HotelOwnerService.getRoomsOfHotel(responses.data,token).then((response)=>{
            console.log("data recevied from getRoomsOfHotel"+JSON.stringify(response.data))
            setRooms(response.data)
        }).catch((error)=> {
            console.log(error);
          })
          .finally(()=> {
            // always executed
          });
        
        })
    },[username,deleteStatus])
  return (
    <div>
      <HotelOwnerNavigation/>
    <div className='container'>
       <h2 className="text-center">Hotel Rooms</h2>
       <table className="table table-bordered table-striped">
            <thead>
                <th>Room Id</th>
                <th>Room Number</th>
                <th>Base Fare</th>
                <th>Max Occupancy</th>
                <th>Is AC</th>
                <th>Bed Preference</th>
            </thead>
            <tbody>
              {rooms.map((rooms,key)=>
              <tr>
                <td>{rooms.roomId}</td>
                <td>{rooms.roomNumber}</td>
                <td>{rooms.baseFare}</td>
                <td>{rooms.maxOccupancy}</td>
                <td>{rooms.isAc ? 'Yes' : 'No'}</td>
                
                {/* <td>{rooms.isAc}</td>
                <td>{rooms.availability}</td> */}
                <td>{rooms.bedPreferences}</td>
                <td>
                    <Link className='btn btn-info' to={`/edit-room/`+rooms.roomId+`/`+username}>Update</Link>
                </td>
                <td>
                    {/* <Link className='btn btn-info' to={/delete-room/+rooms.roomId}>Delete</Link>  */}
                    <button onClick={()=>{deleteRoom(rooms.roomId)}}className='btn btn-danger' >Delete</button>
                </td>
              </tr>)}
            </tbody>
        </table>
        </div>
    </div>
  )
}