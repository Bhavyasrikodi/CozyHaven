// src/components/Footer.jsx
import React from 'react';
import './Footer.css';  // You can style it using a separate CSS file

const Footer = () => {
    return (
        <footer className="footer">
            <div className="footer-content">
                <div className="footer-section about">
                    <h3>About Us</h3>
                    <p>
                        Cozy Haven Stay offers a relaxing and luxurious experience for all our guests. We pride
                        ourselves on delivering comfort and top-notch service across all our hotel branches.
                    </p>
                </div>

                

                <div className="footer-section contact">
                    <h3>Contact Us</h3>
                    <p>Email: <a href="https://mail.google.com/mail/?view=cm&fs=1&to=cozyhavenstayz@gmail.com" target="_blank" rel="noopener noreferrer">cozyhavenstayz@gmail.com</a></p>

                    {/* <p >Email: <a href="mailto:cozyhavenstayz@gmail.com">cozyhavenstayz@gmail.com</a></p> */}
                    <p>Phone: +123-456-7890</p>
                    <p>Address: 123 Cozy Haven Street, Luxury City</p>
                </div>
            </div>

            <div className="footer-bottom">
                <p>&copy; {new Date().getFullYear()} Cozy Haven Stay. All Rights Reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;
