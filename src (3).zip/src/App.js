import logo from './logo.svg';
import './App.css';
import AdminNavigation from './components/Admin/AdminNavigation';
import { AdminDashboard } from './components/Admin/AdminDashboard';
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import { OwnerList } from './components/Admin/OwnerList';
import { ReservationList } from './components/Admin/ReservationList';
import { GuestList } from './components/Admin/GuestList';
import { DisplayHotelReservations } from './components/HotelOwnerPage/DisplayHotelReservations';
import { DisplayHotelGuests } from './components/HotelOwnerPage/DisplayHotelGuests';
import { DisplayHotelRooms } from './components/HotelOwnerPage/DisplayHotelRooms';
import { AddRoom } from './components/HotelOwnerPage/AddRoom';
import { HotelDetails } from './components/HotelOwnerPage/HotelDetails';
import { Homepages } from './components/Homepages';
import { GuestDashboard } from './components/Guest/GuestDashboard';
import { useLocation } from 'react-router-dom';
import { Login } from './components/Login';
import Registration from './components/Registration';
import RequireAuth from './components/RequireAuth';
import { HotelOwnerNavigation } from './components/HotelOwnerPage/HotelOwnerNavigation';
import { HotelOwerDashboard } from './components/HotelOwnerPage/HotelOwerDashboard';
import RoomsPage from './components/Guest/RoomsPage';
import BookingPage from './components/Guest/BookingPage';
import { Payment } from './components/Guest/Payment';
import { MyGuestHistory } from './components/Guest/MyGuestHistory';
import { Review } from './components/Guest/Review';
import Hotelsearch from './components/Guest/Hotelsearch';
import AvailableRoom from './components/Guest/AvailableRoom';
import { RefundList } from './components/HotelOwnerPage/RefundList';
import { AddHotel } from './components/HotelOwnerPage/AddHotel';
import { MyHotelReviews } from './components/HotelOwnerPage/MyHotelReviews';
import Footer from './components/Footer';
function App() {
  const location = useLocation();
  //const showNavigation = !['/login', '/register', '/'].includes(location.pathname);
  return (
    <div className="App">
      

        <Routes>
          {/* Commonpage */}
        <Route path="/" element={<Homepages/>}exact/>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/" element={<Homepages />} />
        <Route element={<RequireAuth />}>
        {/* ADMIN */}
        <Route path="/admin-displayhotels" element={<AdminDashboard/>}/>
        <Route path="/admin-owners" element={<OwnerList />} />
        <Route path="/admin-reservations" element={<ReservationList/>}/>
        <Route path="/admin-guests" element={<GuestList/>}/>
        {/* HOTELOWNER */}
        <Route path="/hotelnav/:username" element={<HotelOwerDashboard/>}/>
        <Route path="/hotel-reservations/:username" element={<DisplayHotelReservations/>} />
        <Route path="/hotel-guests/:username" element={<DisplayHotelGuests/>}/>
        <Route path="/hotel-rooms/:username" element={<DisplayHotelRooms/>}/>
        <Route path="/add-room/:username" element={<AddRoom/>}/>
        <Route path="/edit-room/:roomId/:username" element={<AddRoom/>}/>
        <Route path="/delete-room/:roomId" element={<AddRoom/>}/>
        <Route path="/my-hotel/:username" element={<HotelDetails/>}/>
        <Route path="/add-hotel/:username" element={<AddHotel/>}/>
        <Route path="/refund/:username" element={<RefundList/>}/>
        <Route path="/reviews/:username" element={<MyHotelReviews/>}/>
      {/* GUEST */}
      <Route path="/guest-dashboard/:username" element={<GuestDashboard/>}/>
      <Route path="/see-rooms/:username/:hotelId" element={<RoomsPage/>}/>
      <Route path="/bookingPage/:username/:hotelId/:roomId" element={<BookingPage />} />
      <Route path="/payment/:username/:reservationId" element={<Payment/>}/>
      <Route path="/myHistory/:username" element={<MyGuestHistory/>}/>
      <Route path="/give-review/:username/:hotelId" element={<Review/>}/>
      <Route path="/hotel-results/:username" element={<Hotelsearch />} />
      <Route path="/availablerooms/:username/:hotelId" element={<AvailableRoom/>}/>
      
      </Route>
        </Routes>
        <Footer />
    </div>
  );
}

export default App;
